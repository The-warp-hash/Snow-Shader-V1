// SnowCurvatureBaker.cs
// -----------------------------------------------------------------------------
// EDITOR-ONLY utility. Place this script inside a folder named "Editor"
// anywhere under Assets/ (e.g. Assets/Editor/SnowCurvatureBaker.cs) so Unity
// excludes it from player builds.
//
// WHY THIS EXISTS
// A surface shader's vertex function only ever sees one vertex at a time --
// it has no access to neighbouring triangles, so it cannot tell "this vertex
// is a box corner (convex)" from "this vertex is an inside corner (concave)"
// or "this vertex is a seam between two hard-edged faces" on its own. The
// Custom/SnowDeform shader needs exactly that information for two features:
//
//   - RED   channel: 0 exactly at hard-edge seams (so displacement fades to
//            zero there and never tears the mesh open), 1 elsewhere.
//   - GREEN channel: per-vertex convexity, 0=concave .. 0.5=flat .. 1=convex,
//            used (when _USE_VERTEX_CURVATURE is on) to make box corners and
//            ridges accumulate a visibly thicker coat than flat faces.
//
// This tool computes both directly from the mesh's own geometry and bakes
// them into the mesh's vertex colors, so you don't have to hand-paint them.
//
// HOW IT WORKS
// 1. Groups vertices by (near-identical) POSITION. A hard-edged mesh stores
//    several vertex copies at the same position with different normals (one
//    per face); a smooth mesh stores one vertex per position.
// 2. Within each position group, if any two copies' normals differ by more
//    than "hardEdgeAngleThreshold" degrees, the whole group is treated as a
//    hard-edge seam and gets RED = 0. Otherwise RED = 1.
// 3. For curvature, it builds a topological adjacency list (shared mesh
//    edges from the triangle list) and estimates each vertex's convexity as
//    the average of dot(vertexNormal, neighbourPosition - vertexPosition)
//    across its neighbours, negated so a vertex sticking OUT relative to its
//    neighbours (like a box corner) reads as positive/convex. The raw value
//    is then normalized against the mesh's own size and remapped to 0..1.
// 4. Writes the result into a COPY of the mesh (never mutates a shared asset
//    in place) and, if the source mesh is a project asset, saves the bake as
//    a new .asset next to it (suffix "_SnowBaked") so it survives beyond the
//    current scene/session; otherwise it just assigns the copy at runtime-
//    in-editor so you can see the result immediately.
//
// USAGE
//   Select one or more GameObjects with a MeshFilter in the Hierarchy, then
//   Tools > Snow > Bake Curvature + Seams To Vertex Colors.
// -----------------------------------------------------------------------------

#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public static class SnowCurvatureBaker
{
    // Two vertex-copies at the same position whose normals differ by more
    // than this many degrees are treated as sitting on a hard-edge seam.
    private const float HardEdgeAngleThresholdDegrees = 25f;

    // Positions within this world/local distance are considered "the same
    // point" for grouping purposes (handles floating point noise from
    // import/export round-trips).
    private const float PositionWeldEpsilon = 0.0001f;

    [MenuItem("Tools/Snow/Bake Curvature + Seams To Vertex Colors")]
    private static void BakeSelected()
    {
        var meshFilters = new List<MeshFilter>();
        foreach (var go in Selection.gameObjects)
        {
            var mf = go.GetComponent<MeshFilter>();
            if (mf != null && mf.sharedMesh != null)
            {
                meshFilters.Add(mf);
            }
        }

        if (meshFilters.Count == 0)
        {
            EditorUtility.DisplayDialog("Snow Curvature Baker",
                "Select one or more GameObjects with a MeshFilter first.", "OK");
            return;
        }

        int done = 0;
        foreach (var mf in meshFilters)
        {
            Undo.RecordObject(mf, "Bake Snow Curvature");
            Mesh baked = BakeMesh(mf.sharedMesh);
            mf.sharedMesh = baked;
            done++;
        }

        AssetDatabase.SaveAssets();
        Debug.Log("SnowCurvatureBaker: baked curvature + seam vertex colors on " + done + " mesh(es).");
    }

    private static Mesh BakeMesh(Mesh source)
    {
        Mesh mesh = Object.Instantiate(source);
        mesh.name = source.name + "_SnowBaked";

        Vector3[] positions = mesh.vertices;
        Vector3[] normals = mesh.normals;
        int[] triangles = mesh.triangles;
        int vertCount = positions.Length;

        if (normals == null || normals.Length != vertCount)
        {
            mesh.RecalculateNormals();
            normals = mesh.normals;
        }

        // --- Build topological adjacency (shared edges from triangles) ---
        var adjacency = new HashSet<int>[vertCount];
        for (int i = 0; i < vertCount; i++) adjacency[i] = new HashSet<int>();

        for (int t = 0; t < triangles.Length; t += 3)
        {
            int a = triangles[t];
            int b = triangles[t + 1];
            int c = triangles[t + 2];
            adjacency[a].Add(b); adjacency[a].Add(c);
            adjacency[b].Add(a); adjacency[b].Add(c);
            adjacency[c].Add(a); adjacency[c].Add(b);
        }

        // --- Group vertices by near-identical position (for seam + for
        //     curvature we also want ALL co-located copies to share one
        //     final curvature value, so corners agree across their split
        //     face-copies instead of each copy computing its own). ---
        var positionGroups = new Dictionary<Vector3Int, List<int>>();
        Vector3Int Key(Vector3 p) => new Vector3Int(
            Mathf.RoundToInt(p.x / PositionWeldEpsilon),
            Mathf.RoundToInt(p.y / PositionWeldEpsilon),
            Mathf.RoundToInt(p.z / PositionWeldEpsilon));

        for (int i = 0; i < vertCount; i++)
        {
            var key = Key(positions[i]);
            if (!positionGroups.TryGetValue(key, out var list))
            {
                list = new List<int>();
                positionGroups[key] = list;
            }
            list.Add(i);
        }

        // Mesh size, used to normalize the raw curvature estimate into a
        // sane 0..1 range regardless of whether this mesh is a 1-unit crate
        // or a 50-unit boulder.
        float meshScale = Mathf.Max(mesh.bounds.extents.magnitude, 0.001f);

        float[] rawCurvature = new float[vertCount];
        for (int i = 0; i < vertCount; i++)
        {
            var neighbours = adjacency[i];
            if (neighbours.Count == 0) { rawCurvature[i] = 0f; continue; }

            float sum = 0f;
            foreach (int n in neighbours)
            {
                Vector3 toNeighbour = positions[n] - positions[i];
                // Neighbour "behind" the outward normal -> this vertex
                // sticks out relative to it -> convex -> want positive.
                sum += -Vector3.Dot(normals[i], toNeighbour);
            }
            rawCurvature[i] = sum / neighbours.Count;
        }

        // --- Average raw curvature across co-located copies, then
        //     normalize + remap to 0..1, and decide the seam (red) mask
        //     per position group. ---
        var colors = new Color[vertCount];
        foreach (var kvp in positionGroups)
        {
            List<int> group = kvp.Value;

            // Seam detection: any pair of normals in this group further
            // apart than the threshold marks the whole group as a seam.
            bool isSeam = false;
            for (int a = 0; a < group.Count && !isSeam; a++)
            {
                for (int b = a + 1; b < group.Count; b++)
                {
                    float angle = Vector3.Angle(normals[group[a]], normals[group[b]]);
                    if (angle > HardEdgeAngleThresholdDegrees) { isSeam = true; break; }
                }
            }
            float red = isSeam ? 0f : 1f;

            float avgRaw = 0f;
            foreach (int idx in group) avgRaw += rawCurvature[idx];
            avgRaw /= group.Count;

            // Normalize by mesh scale so the same threshold constant works
            // across different mesh sizes, then squash into 0..1 with a
            // soft curve so typical geometry doesn't just clip to 0 or 1.
            float normalized = avgRaw / meshScale;
            float green = Mathf.Clamp01(0.5f + normalized * 4f);

            foreach (int idx in group)
            {
                colors[idx] = new Color(red, green, 0f, 1f);
            }
        }

        mesh.colors = colors;

        // If the source mesh is a project asset (not a built-in primitive or
        // an in-memory mesh), persist the bake as a sibling .asset so it
        // survives beyond this editor session.
        string sourcePath = AssetDatabase.GetAssetPath(source);
        if (!string.IsNullOrEmpty(sourcePath))
        {
            string dir = Path.GetDirectoryName(sourcePath);
            string newPath = AssetDatabase.GenerateUniqueAssetPath(
                Path.Combine(dir, mesh.name + ".asset"));
            AssetDatabase.CreateAsset(mesh, newPath);
        }

        return mesh;
    }
}
#endif
