// SnowDeformAreaGizmo.cs
// -----------------------------------------------------------------------------
// Attach to any object using Custom/SnowDeform (or a single dedicated debug
// object) to draw the world-space footstep displacement area exactly as the
// SHADER currently reads it -- i.e. straight from the material's own
// _SnowWorldAreaSize / _SnowWorldCenter values -- rather than assuming it
// matches whatever a FootstepPainter elsewhere in the scene is configured
// with. Useful when those two can drift apart: multiple FootstepPainter
// instances, a material with _WORLDSPACE_UV enabled that isn't fed by any
// painter, or hand-edited material values.
//
// Complements (does not replace) FootstepPainter's own OnDrawGizmosSelected,
// which shows the area IT is painting into.
//
// LIMITATION: Unity 2019.4's scripting API has no way to read back a live
// value pushed via Shader.SetGlobalFloat/SetGlobalVector -- that query API
// (Shader.GetGlobalFloat etc.) was only added in later Unity versions. So
// this gizmo reflects the material's own authored/serialized values, not a
// global override that some other script may be driving at runtime. If
// FootstepPainter.syncGlobalShaderProperties is true (the default) and
// nothing else is overriding those globals, the two will match; if you're
// unsure, cross-check against FootstepPainter's own gizmo.
// -----------------------------------------------------------------------------

using UnityEngine;

[ExecuteAlways]
public class SnowDeformAreaGizmo : MonoBehaviour
{
    [Tooltip("Material to inspect. Leave empty to auto-grab this object's Renderer material.")]
    public Material material;

    [Tooltip("Gizmo wire colour.")]
    public Color gizmoColor = new Color(1f, 0.4f, 0f, 0.6f);

    [Tooltip("Only draw when this GameObject is selected in the Scene view. " +
             "Turn off to always show the area regardless of selection.")]
    public bool onlyWhenSelected = true;

#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        if (onlyWhenSelected) return;
        DrawAreaGizmo();
    }

    void OnDrawGizmosSelected()
    {
        if (!onlyWhenSelected) return;
        DrawAreaGizmo();
    }

    void DrawAreaGizmo()
    {
        Material mat = ResolveMaterial();
        if (mat == null) return;

        // Nothing extra to show in mesh-UV mode -- the "area" there is just
        // the mesh itself, which is already visible.
        if (!mat.IsKeywordEnabled("_WORLDSPACE_UV")) return;

        float size = mat.HasProperty("_SnowWorldAreaSize") ? mat.GetFloat("_SnowWorldAreaSize") : 50f;
        Vector4 center = mat.HasProperty("_SnowWorldCenter") ? mat.GetVector("_SnowWorldCenter") : Vector4.zero;

        Gizmos.color = gizmoColor;
        Gizmos.DrawWireCube(new Vector3(center.x, center.y, center.z), new Vector3(size, 0.01f, size));

        // Small cross at the center so it's easy to spot even when the box
        // is huge relative to the object it's attached to.
        Vector3 c = new Vector3(center.x, center.y, center.z);
        float crossSize = Mathf.Max(size * 0.02f, 0.25f);
        Gizmos.DrawLine(c - Vector3.right * crossSize, c + Vector3.right * crossSize);
        Gizmos.DrawLine(c - Vector3.forward * crossSize, c + Vector3.forward * crossSize);
    }

    Material ResolveMaterial()
    {
        if (material != null) return material;
        Renderer r = GetComponent<Renderer>();
        if (r == null) return null;
        return Application.isPlaying ? r.material : r.sharedMaterial;
    }
#endif
}
