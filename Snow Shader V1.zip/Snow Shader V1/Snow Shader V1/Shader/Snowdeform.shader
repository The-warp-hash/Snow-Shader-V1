﻿Shader "Custom/SnowDeform"
{
    Properties
    {
        [Header(Ground)]
        _MainTex ("Ground Albedo", 2D) = "white" {}
        _Glossiness ("Ground Smoothness", Range(0,1)) = 0.4
        _Metallic ("Ground Metallic", Range(0,1)) = 0.0

        [Header(Snow Textures)]
        _SnowColor ("Snow Tint", Color) = (1,1,1,1)
        _SnowAlbedo ("Snow Albedo", 2D) = "white" {}
        [Normal] _SnowNormal ("Snow Normal Map (Tangent Space)", 2D) = "bump" {}
        _SnowNormalScale ("Snow Normal Scale", Range(0,2)) = 1.0
        _SnowHeightNoise ("Snow Noise (grayscale; drives both micro detail and volumetric mounds)", 2D) = "gray" {}
        _SnowMicroDetailTiling ("Snow Micro Detail Tiling (mesh UV space)", Float) = 8.0
        _SnowMicroDetailStrength ("Snow Micro Detail Strength", Range(0,2)) = 0.5

        _SnowTiling ("Snow Albedo Tiling (XY)", Vector) = (1,1,0,0)
        _SnowOffset ("Snow Albedo Offset (XY)", Vector) = (0,0,0,0)

        [Header(Snow PBR)]
        _SnowGlossiness ("Snow Smoothness", Range(0,1)) = 0.8
        _SnowMetallic ("Snow Metallic", Range(0,1)) = 0.0

        [Toggle(_SNOW_NORMAL_MIN_COVERAGE)] _LimitSnowNormal ("Fade Snow Normal At Low Coverage", Float) = 1
        _SnowNormalMinCoverage ("Snow Normal Min Coverage", Range(0,1)) = 0.1

        [Header(Snow Coverage Mask)]
        _SnowAmount ("Local Snow Amount (meters)", Range(0, 0.3)) = 0.05
        _GlobalSnowHeight ("Global Snow Height Add-On (meters)", Range(0, 0.3)) = 0.0

        _SnowThreshold ("Snow Slope Threshold", Range(0, 1)) = 0.5
        _SnowTransition ("Snow Transition Softness (0=hard edge, 1=soft gradient)", Range(0, 1)) = 0.3

        _SnowHeightMin ("Snow World Height Min", Float) = 0.0
        _SnowHeightMax ("Snow World Height Max", Float) = 10.0
        _SnowHeightInfluence ("Snow Height Influence", Range(0, 1)) = 0.0

        [Header(Volumetric Snow Shaping)]
        _SnowMoundTiling ("Mound Noise World Tiling", Float) = 0.6
        _SnowMoundStrength ("Mound Noise Height Variance", Range(0, 1)) = 0.6

        [Toggle(_SNOW_MOUND_SPREAD)] _EnableMoundSpread ("Enable Mound Lateral Spread", Float) = 1
        _SnowMoundSpread ("Mound Lateral Spread (meters)", Range(0, 0.5)) = 0.08

        [Toggle(_USE_VERTEX_CURVATURE)] _UseVertexCurvature ("Use Baked Vertex Curvature For Corner Bulge", Float) = 0
        _SnowCurvatureStrength ("Curvature Bulge Strength (meters)", Range(0, 0.3)) = 0.08

        _SnowMaxThickness ("Max Total Snow Thickness (meters)", Range(0, 0.6)) = 0.35

        [Toggle(_SNOW_PUFF_BUMP)] _EnablePuffBump ("Enable Fragment Puffiness Bump", Float) = 1
        _SnowPuffiness ("Puffiness Bump Strength", Range(0, 1)) = 0.35

        [Header(Footstep Deformation)]
        _DisplacementTex ("Footstep Displacement (RT)", 2D) = "white" {}
        _DeformationAmount ("Deformation Amount (meters)", Range(0, 0.2)) = 0.05
        _DeformationDepth ("Deformation Depth Multiplier", Range(0, 3)) = 1.0
        _DeformationRadius ("Deformation Read Radius (meters)", Range(0, 2)) = 0.3
        _DeformationDirectionality ("Deformation Directionality", Range(0, 1)) = 0.0

        [Toggle(_WORLDSPACE_UV)] _UseWorldSpaceUV ("Sample Displacement Using World-Space XZ UV", Float) = 0
        _SnowWorldAreaSize ("Snow World Area Size (meters)", Float) = 50
        _SnowWorldCenter ("Snow World Center", Vector) = (0, 0, 0, 0)

        [Header(Mesh Seam Safety)]
        [Toggle(_DISABLE_SNOW_DISPLACEMENT)] _DisableSnowDisplacement ("Disable Vertex Displacement (visual-only fallback)", Float) = 0
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 200

        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows vertex:vert addshadow
        #pragma target 3.0
        #pragma shader_feature _WORLDSPACE_UV
        #pragma shader_feature _SNOW_NORMAL_MIN_COVERAGE
        #pragma shader_feature _DISABLE_SNOW_DISPLACEMENT
        #pragma shader_feature _USE_VERTEX_CURVATURE
        #pragma shader_feature _SNOW_MOUND_SPREAD
        #pragma shader_feature _SNOW_PUFF_BUMP

        sampler2D _MainTex;
        sampler2D _SnowAlbedo;
        sampler2D _SnowNormal;
        sampler2D _SnowHeightNoise;
        sampler2D _DisplacementTex;

        struct Input
        {
            float2 uv_MainTex;
            float snowLerp;
            float footDepth;
            float3 worldPos;
            float3 snowWorldNormal;
        };

        half _Glossiness;
        half _Metallic;
        fixed4 _SnowColor;

        half _SnowNormalScale;
        float _SnowMicroDetailTiling;
        half _SnowMicroDetailStrength;
        float4 _SnowTiling;
        float4 _SnowOffset;

        half _SnowGlossiness;
        half _SnowMetallic;
        half _SnowNormalMinCoverage;

        half _SnowAmount;
        half _GlobalSnowHeight;
        half _SnowThreshold;
        half _SnowTransition;
        float _SnowHeightMin;
        float _SnowHeightMax;
        half _SnowHeightInfluence;

        float _SnowMoundTiling;
        half _SnowMoundStrength;
        half _SnowMoundSpread;
        half _SnowCurvatureStrength;
        half _SnowMaxThickness;
        half _SnowPuffiness;

        half _DeformationAmount;
        half _DeformationDepth;
        half _DeformationRadius;
        half _DeformationDirectionality;

        float _SnowWorldAreaSize;
        float4 _SnowWorldCenter;

        float SampleMoundNoiseWS(float3 worldPos, float3 worldNormal)
        {
            float3 blend = abs(worldNormal);
            blend /= (blend.x + blend.y + blend.z + 1e-5);

            float2 uvX = worldPos.yz * _SnowMoundTiling;
            float2 uvY = worldPos.xz * _SnowMoundTiling;
            float2 uvZ = worldPos.xy * _SnowMoundTiling;

            float nX = tex2Dlod(_SnowHeightNoise, float4(uvX, 0, 0)).r;
            float nY = tex2Dlod(_SnowHeightNoise, float4(uvY, 0, 0)).r;
            float nZ = tex2Dlod(_SnowHeightNoise, float4(uvZ, 0, 0)).r;

            return nX * blend.x + nY * blend.y + nZ * blend.z;
        }

        void SampleFootstepDepth(float2 uv, out float depth, out float2 gradient)
        {
            float radiusUV = _DeformationRadius / max(_SnowWorldAreaSize, 0.0001);

            float d0  = 1.0 - tex2Dlod(_DisplacementTex, float4(uv, 0, 0)).r;
            float dxp = 1.0 - tex2Dlod(_DisplacementTex, float4(uv + float2( radiusUV, 0), 0, 0)).r;
            float dxn = 1.0 - tex2Dlod(_DisplacementTex, float4(uv + float2(-radiusUV, 0), 0, 0)).r;
            float dyp = 1.0 - tex2Dlod(_DisplacementTex, float4(uv + float2(0,  radiusUV), 0, 0)).r;
            float dyn = 1.0 - tex2Dlod(_DisplacementTex, float4(uv + float2(0, -radiusUV), 0, 0)).r;

            depth = (d0 * 2.0 + dxp + dxn + dyp + dyn) / 6.0;

            gradient = float2(dxp - dxn, dyp - dyn);
        }

        void vert(inout appdata_full v, out Input o)
        {
            UNITY_INITIALIZE_OUTPUT(Input, o);

            float3 worldNormal = UnityObjectToWorldNormal(v.normal);
            float3 worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
            float upDot = dot(worldNormal, float3(0, 1, 0));

            float band = lerp(0.001, 0.5, _SnowTransition);
            float slopeMask = smoothstep(_SnowThreshold - band, _SnowThreshold + band, upDot);
            float heightMask = smoothstep(_SnowHeightMin, _SnowHeightMax, worldPos.y);
            float combinedMask = slopeMask * lerp(1.0, heightMask, _SnowHeightInfluence);

            #if defined(_WORLDSPACE_UV)
                float2 dispUV = ((worldPos.xz - _SnowWorldCenter.xz) / max(_SnowWorldAreaSize, 0.0001)) + 0.5;
            #else
                float2 dispUV = v.texcoord.xy;
            #endif

            float footDepth;
            float2 footGradient;
            SampleFootstepDepth(dispUV, footDepth, footGradient);

            float baseHeight = clamp(_SnowAmount + _GlobalSnowHeight, 0.0, _SnowMaxThickness);

            float noiseSigned = SampleMoundNoiseWS(worldPos, worldNormal) * 2.0 - 1.0;
            float moundHeight = baseHeight * (1.0 + noiseSigned * _SnowMoundStrength);

            #if defined(_USE_VERTEX_CURVATURE)
                float curvature = v.color.g * 2.0 - 1.0;
                moundHeight += curvature * _SnowCurvatureStrength;
            #endif

            moundHeight = clamp(moundHeight, 0.0, _SnowMaxThickness);

            float targetSnowHeight = moundHeight * combinedMask;
            float deformationPush = (_DeformationAmount * _DeformationDepth) * footDepth * combinedMask;
            float netDisplacement = clamp(targetSnowHeight - deformationPush, 0.0, _SnowMaxThickness);

            float edgeMask = v.color.r;

            #if !defined(_DISABLE_SNOW_DISPLACEMENT)

                v.vertex.xyz += v.normal * netDisplacement * edgeMask;

                #if defined(_SNOW_MOUND_SPREAD)
                    float3 worldTangent = normalize(UnityObjectToWorldDir(v.tangent.xyz));
                    float3 worldBitangent = cross(worldNormal, worldTangent) * v.tangent.w;

                    float eps = max(0.1 / max(_SnowMoundTiling, 0.001), 0.05);
                    float gradT = SampleMoundNoiseWS(worldPos + worldTangent * eps, worldNormal)
                                - SampleMoundNoiseWS(worldPos - worldTangent * eps, worldNormal);
                    float gradB = SampleMoundNoiseWS(worldPos + worldBitangent * eps, worldNormal)
                                - SampleMoundNoiseWS(worldPos - worldBitangent * eps, worldNormal);

                    float3 spreadWS = (worldTangent * gradT + worldBitangent * gradB)
                                       * _SnowMoundSpread * combinedMask * edgeMask;
                    v.vertex.xyz += mul((float3x3)unity_WorldToObject, spreadWS);
                #endif

                float3 smearDirOS;
                #if defined(_WORLDSPACE_UV)
                    float3 smearDirWS = float3(footGradient.x, 0, footGradient.y);
                    smearDirOS = mul((float3x3)unity_WorldToObject, smearDirWS);
                #else
                    float3 bitangentOS = cross(v.normal, v.tangent.xyz) * v.tangent.w;
                    smearDirOS = v.tangent.xyz * footGradient.x + bitangentOS * footGradient.y;
                #endif
                v.vertex.xyz += smearDirOS * footDepth * _DeformationDirectionality * deformationPush * edgeMask;

            #endif

            o.snowLerp = combinedMask;
            o.footDepth = footDepth;
            o.snowWorldNormal = worldNormal;
        }

        void surf(Input IN, inout SurfaceOutputStandard o)
        {
            fixed4 baseCol = tex2D(_MainTex, IN.uv_MainTex);

            float2 snowUV = IN.uv_MainTex * _SnowTiling.xy + _SnowOffset.xy;
            fixed4 snowTex = tex2D(_SnowAlbedo, snowUV) * _SnowColor;

            float micro = tex2D(_SnowHeightNoise, snowUV * _SnowMicroDetailTiling).r;
            snowTex.rgb *= lerp(1.0 - _SnowMicroDetailStrength * 0.5,
                                 1.0 + _SnowMicroDetailStrength * 0.5,
                                 micro);

            snowTex.rgb *= lerp(1.0, 0.85, saturate(IN.footDepth) * IN.snowLerp);

            fixed4 finalColor = lerp(baseCol, snowTex, IN.snowLerp);
            o.Albedo = finalColor.rgb;
            o.Alpha = finalColor.a;

            o.Metallic = lerp(_Metallic, _SnowMetallic, IN.snowLerp);
            o.Smoothness = lerp(_Glossiness, _SnowGlossiness, IN.snowLerp);

            half3 snowNormalTS = UnpackScaleNormal(tex2D(_SnowNormal, snowUV), _SnowNormalScale);

            #if defined(_SNOW_PUFF_BUMP)
                float moundH = SampleMoundNoiseWS(IN.worldPos, IN.snowWorldNormal);
                float2 puffTS = float2(ddx(moundH), ddy(moundH)) * -8.0 * _SnowPuffiness;
                snowNormalTS.xy += puffTS;
            #endif

            half normalMask = IN.snowLerp;
            #if defined(_SNOW_NORMAL_MIN_COVERAGE)
                normalMask *= step(_SnowNormalMinCoverage, IN.snowLerp);
            #endif
            o.Normal = normalize(lerp(half3(0, 0, 1), snowNormalTS, normalMask));
        }
        ENDCG
    }
    FallBack "Diffuse"
}